printf "Press 1 to search for Age:\n%s";
printf "Press 2 to search for Sex:\n%s";
printf "Press 3 to search for Cp:\n%s";
printf "Press 4 to search for trtbps:\n%s";
printf "Press 5 to search for Chol:\n%s";
printf "Press 6 to search for fbs:\n%s";
printf "Press 7 to search for Restecg:\n%s";
printf "Press 8 to search for Thalachh:\n%s";
printf "Press 9 to search for Exng:\n%s";
printf "Press 10 to search for Oldpeak:\n%s";
printf "Press 11 to search for Slp:\n%s";
printf "Press 12 to search for Caa:\n%s";
printf "Press 13 to search for thall:\n%s";
printf "Press 14 to search for Output:\n%s";



read choice;
printf " $choice \n%s";


if [ $choice -eq 1 ]
then
printf "please enter age to search:\n%s"; read pattern; awk -v patt="$pattern" -F',' '$1 == patt' heart.csv
fi

if [ $choice -eq 2 ]
then
printf "please enter sex to search:\n%s"; read pattern; awk -v patt="$pattern" -F',' '$2 == patt' heart.csv
fi

if [ $choice -eq 3 ]
then
printf "please enter cp to search.\n%s"; read pattern; awk -v patt="$pattern" -F',' '$3 == patt' heart.csv
fi

if [ $choice -eq 4 ]
then
printf "please enter trtbps to search:\n%s"; read pattern; awk -v patt="$pattern" -F',' '$4 == patt' heart.csv
fi

if [ $choice -eq 5 ]
then
printf "please enter chol to search:\n%s"; read pattern; awk -v patt="$pattern" -F',' '$5 == patt' heart.csv 
fi

if [ $choice -eq 6 ]
then
printf "please enter fbs to search:\n%s"; read pattern; awk -v patt="$pattern" -F',' '$6 == patt' heart.csv
fi

if [ $choice -eq 7 ]
then
printf "please enter restecg to search:\n%s"; read pattern; awk -v patt="$pattern" -F',' '$7 == patt' heart.csv
fi

if [ $choice -eq 8 ]
then
printf "please enter thalachh to search:\n%s"; read pattern; awk -v patt="$pattern" -F',' '$8 == patt' heart.csv
fi

if [ $choice -eq 9 ]
then
printf "please enter exng to search:\n%s"; read pattern; awk -v patt="$pattern" -F',' '$9 == patt' heart.csv
fi

if [ $choice -eq 10 ]
then
printf "please enter oldpeak to search:\n%s"; read pattern; awk -v patt="$pattern" -F',' '$10 == patt' heart.csv
fi

if [ $choice -eq 11 ]
then
printf "please enter slp to search:\n%s"; read pattern; awk -v patt="$pattern" -F',' '$11 == patt' heart.csv
fi

if [ $choice -eq 12 ]
then
printf "please enter caa to search:\n%s"; read pattern; awk -v patt="$pattern" -F',' '$12 == patt' heart.csv
fi

if [ $choice -eq 13 ]
then
printf "please enter thall to search:\n%s"; read pattern; awk -v patt="$pattern" -F',' '$13 == patt' heart.csv
fi

if [ $choice -eq 14 ]
then
printf "please enter output to search:\n%s"; read pattern; awk -v patt="$pattern" -F',' '$14 == patt' heart.csv
fi
