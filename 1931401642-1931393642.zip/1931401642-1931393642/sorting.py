import csv

file = open("heart.csv")

def list_to_dict(list):
    return {'Age': list[0], 'Sex': list[1], 'Cp': list[2], 'trtbps': list[3], 'chol': list[4], 'fbs': list[5], 'restecg': list[6]}
list = []
for line in file.readlines():
    array = line.replace('\n', '').split(',')
    dict = list_to_dict(array)
    list.append(dict)

list = sorted(list, key=lambda x: x['Age'])

for dict in list:
    print(dict)