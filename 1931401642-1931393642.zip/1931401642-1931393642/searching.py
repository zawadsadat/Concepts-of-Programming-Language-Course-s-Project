import csv
def searchByAge():
    age = input("Enter the age :")
    csv_file = csv.reader(open('heart.csv', 'r'))
    for row in csv_file:
        if age == row[0]:
            print(row)

def searchBySex():
        sex = input("Enter Sex no :")
        csv_file = csv.reader(open('heart.csv', 'r'))
        for row in csv_file:
            if sex == row[1]:
                print(row)

def searchByCp():
    cp = input("Enter Cp :")
    csv_file = csv.reader(open('heart.csv', 'r'))

    for row in csv_file:
        if cp == row[2]:
            print(row)

def searchByTrtbps():
    trtbps = input("Enter trtbps :")
    csv_file = csv.reader(open('heart.csv', 'r'))

    for row in csv_file:
        if trtbps == row[3]:
            print(row)

def searchByChol():
    chol= input("Enter the Chol :")
    csv_file = csv.reader(open('heart.csv', 'r'))

    for row in csv_file:
        if chol == row[4]:
            print(row)

def searchByFbs():
    fbs = input("Enter the FBS :")
    csv_file = csv.reader(open('heart.csv', 'r'))

    for row in csv_file:
        if fbs == row[5]:
            print(row)

def searchByRestecg():
    restecg = input("Enter the Restecg:")
    csv_file = csv.reader(open('heart.csv', 'r'))

    for row in csv_file:
        if restecg == row[6]:
            print(row)

def searchByThalachh():
    thalachh = input("Enter the Thalachh :")
    csv_file = csv.reader(open('heart.csv', 'r'))

    for row in csv_file:
        if thalachh== row[7]:
            print(row)

def searchByExng():
    exng = input("Enter the Exng :")
    csv_file = csv.reader(open('heart.csv', 'r'))

    for row in csv_file:
        if exng== row[8]:
            print(row)

def searchByOldpeak():
    oldpeak = input("Enter the oldpeak :")
    csv_file = csv.reader(open('heart.csv', 'r'))

    for row in csv_file:
        if oldpeak== row[9]:
            print(row)

def searchBySlp():
    slp = input("Enter the slp :")
    csv_file = csv.reader(open('heart.csv', 'r'))

    for row in csv_file:
        if slp== row[10]:
            print(row)

def searchByCaa():
    caa = input("Enter the caa :")
    csv_file = csv.reader(open('heart.csv', 'r'))

    for row in csv_file:
        if caa== row[11]:
            print(row)

def searchByThall():
    thall = input("Enter the thall :")
    csv_file = csv.reader(open('heart.csv', 'r'))

    for row in csv_file:
        if thall== row[12]:
            print(row)

def searchByOutput():
    output = input("Enter the output :")
    csv_file = csv.reader(open('heart.csv', 'r'))

    for row in csv_file:
        if output== row[13]:
            print(row)
print("Enter 1 to search by Age:")
print("Enter 2 to search by Sex:")
print("Enter 3 to search by Cp:")
print("Enter 4 to search by trtbps:")
print("Enter 5 to search by Chol:")
print("Enter 6 to search by Fbs:")
print("Enter 7 to search by Restecg:")
print("Enter 8 to search by Thalachh:")
print("Enter 9 to search by Exng:")
print("Enter 10 to search by Oldpeak:")
print("Enter 11 to search by Slp:")
print("Enter 12 to search by Caa:")
print("Enter 13 to search by Thall:")
print("Enter 14 to search by Output:")
src = int(input("Enter here :"))

if src == 1:
    searchByAge()
elif src == 2:
    searchBySex()
elif src == 3:
    searchByCp()
elif src == 4:
    searchByTrtbps()
elif src == 5:
    searchByChol()
elif src == 6:
    searchByFbs()
elif src == 7:
    searchByRestecg()
elif src == 8:
    searchByThalachh()
elif src == 9:
    searchByExng()
elif src == 10:
    searchByOldpeak()
elif src == 11:
    searchBySlp()
elif src == 12:
    searchByCaa()
elif src == 13:
    searchByThall()
elif src == 14:
    searchByOutput()
else:
    print("Sorry, Invalid input...")
print("Thank you!!!")