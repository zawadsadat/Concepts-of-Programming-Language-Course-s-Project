#include <iostream>
#include <fstream>
#include <string>
#include <strstream>
#include <vector>
#include <algorithm>
using namespace std;

int main ()
{
    string age;
    string sex;
    string cp;
    string trtbps;
    string chol;
    string fbs;
    string restecg;
    string thalachh;
    string exng;
    string oldpeak;
    string slp;
    string caa;
    string thall;
    string output;
    string row_data;
    string ageinput;
    string sexinput;
    string cpinput;
    string trtbpsinput;
    string cholinput;
    string fbsinput;
    string restecginput;
    string thalachhinput;
    string exnginput;
    string oldpeakinput;
    string slpinput;
    string caainput;
    string thallinput;
    string outputinput;
    string choice;
    vector<string> row;

    cout<<"Press 1 to search Age\n";
    cout<<"Press 2 to search Sex\n";
    cout<<"Press 3 to search Cp\n";
    cout<<"Press 4 to search Trtbps\n";
    cout<<"Press 5 to search Chol\n";
    cout<<"Press 6 to search Fbs\n";
    cout<<"Press 7 to search restecg\n";
    cout<<"Press 8 to search Thalachh\n";
    cout<<"Press 9 to search Exng\n";
    cout<<"Press 10 to search Oldpeak\n";
    cout<<"Press 11 to search Slp\n";
    cout<<"Press 12 to search Caa\n";
    cout<<"Press 13 to search Thall\n";
    cout<<"Press 14 to search Output\n";
    cout<<"Press 15 to sort\n";
    cout<<"Press 16 to Exit";

    while(true)
    {
        cout<<"\nWhich number you want to search?\n";
        ifstream ip("heart.csv");

        if(!ip.is_open())
            std::cout << "ERROR OPENING FILE" << '\n';
        cin>> choice;

        if (choice == "1")
        {
            cout<<"Enter Age\n";
            cin>> ageinput;

            while(ip.good())
            {
                getline(ip,age,',');
                getline(ip,sex,',');
                getline(ip,cp,',');
                getline(ip,trtbps,',');
                getline(ip,chol,',');
                getline(ip,fbs,',');
                getline(ip,restecg,',');
                getline(ip,thalachh,',');
                getline(ip,exng, ',');
                getline(ip,oldpeak,',');
                getline(ip,slp,',');
                getline(ip,caa,',');
                getline(ip,thall,',');
                getline(ip,output,'\n');

                if (ageinput == age)
                {
                    std::cout<<"age" <<" "<<"sex"<< " " <<"cp"<<" "<<"trtbps"<<" " <<"chol"<<" "<<"fbs"<<" "<<"restecg"<< " " << "oldpeak"<< " " <<"exng"<< " "<< "thalachh"<< " "<<"slp"<< " "<< "thall"<< " "<< "caa"<< " "<<"output"<<'\n';
                    std::cout<<age <<"  "<<sex<< "   " <<cp<<"   "<<trtbps<<"   " <<chol<<"   "<<fbs<<"    "<<restecg<< "      " << oldpeak<< "      "<<exng<<"     "<< thalachh<< "     "<<slp<< "    "<<thall<< "    "<< caa<<"    "<<output<<'\n';
                }
            }

            ip.close();
        }


        if (choice == "2")
        {
            cout<<"Enter Sex No\n";
            cin>> sexinput;

            while(ip.good())
            {
                getline(ip,age,',');
                getline(ip,sex,',');
                getline(ip,cp,',');
                getline(ip,trtbps,',');
                getline(ip,chol,',');
                getline(ip,fbs,',');
                getline(ip,restecg,',');
                getline(ip,thalachh,',');
                getline(ip,exng, ',');
                getline(ip,oldpeak,',');
                getline(ip,slp,',');
                getline(ip,caa,',');
                getline(ip,thall,',');
                getline(ip,output,'\n');

                if (sexinput == sex)
                {
                    std::cout<<"age" <<" "<<"sex"<< " " <<"cp"<<" "<<"trtbps"<<" " <<"chol"<<" "<<"fbs"<<" "<<"restecg"<< " " << "oldpeak"<< " " <<"exng"<< " "<< "thalachh"<< " "<<"slp"<< " "<< "thall"<< " "<< "caa"<< " "<< "output"<<'\n';
                    std::cout<<age <<"  "<<sex<< "   " <<cp<<"   "<<trtbps<<"   " <<chol<<"   "<<fbs<<"    "<<restecg<< "      " << oldpeak<< "      "<<exng<<"     "<< thalachh<< "     "<<slp<< "    "<<thall<< "    "<< caa<<"   "<<output<<'\n';
                }
            }

            ip.close();
        }

        if (choice == "3")
        {
            cout<<"Enter Cp\n";
            cin>> cpinput;

            while(ip.good())
            {
                getline(ip,age,',');
                getline(ip,sex,',');
                getline(ip,cp,',');
                getline(ip,trtbps,',');
                getline(ip,chol,',');
                getline(ip,fbs,',');
                getline(ip,restecg,',');
                getline(ip,thalachh,',');
                getline(ip,exng, ',');
                getline(ip,oldpeak,',');
                getline(ip,slp,',');
                getline(ip,caa,',');
                getline(ip,thall,',');
                getline(ip,output,'\n');

                if (cpinput == cp)
                {
                    std::cout<<"age" <<" "<<"sex"<< " " <<"cp"<<" "<<"trtbps"<<" " <<"chol"<<" "<<"fbs"<<" "<<"restecg"<< " " << "oldpeak"<< " " <<"exng"<< " "<< "thalachh"<< " "<<"slp"<< " "<< "thall"<< " "<< "caa"<<" "<<"output"<< '\n';
                    std::cout<<age <<"  "<<sex<< "   " <<cp<<"   "<<trtbps<<"   " <<chol<<"   "<<fbs<<"    "<<restecg<< "      " << oldpeak<< "      "<<exng<<"     "<< thalachh<< "     "<<slp<< "    "<<thall<< "    "<< caa<<"   "<< output<<'\n';
                }
            }

            ip.close();
        }

        if (choice == "4")
        {
            cout<<"Enter Trtbps\n";
            cin>> trtbpsinput;

            while(ip.good())
            {
                getline(ip,age,',');
                getline(ip,sex,',');
                getline(ip,cp,',');
                getline(ip,trtbps,',');
                getline(ip,chol,',');
                getline(ip,fbs,',');
                getline(ip,restecg,',');
                getline(ip,thalachh,',');
                getline(ip,exng, ',');
                getline(ip,oldpeak,',');
                getline(ip,slp,',');
                getline(ip,caa,',');
                getline(ip,thall,',');
                getline(ip,output,'\n');

                if (trtbpsinput == trtbps)
                {
                    std::cout<<"age" <<" "<<"sex"<< " " <<"cp"<<" "<<"trtbps"<<" " <<"chol"<<" "<<"fbs"<<" "<<"restecg"<< " " << "oldpeak"<< " " <<"exng"<< " "<< "thalachh"<< " "<<"slp"<< " "<< "thall"<< " "<< "caa"<< " "<<"output"<< '\n';
                    std::cout<<age <<"  "<<sex<< "   " <<cp<<"   "<<trtbps<<"   " <<chol<<"   "<<fbs<<"    "<<restecg<< "      " << oldpeak<< "      "<<exng<<"     "<< thalachh<< "     "<<slp<< "    "<<thall<< "    "<< caa<<"   "<< output<< '\n';
                }
            }

            ip.close();
        }

        if (choice == "5")
        {
            cout<<"Enter Chol\n";
            cin>> cholinput;

            while(ip.good())
            {
                getline(ip,age,',');
                getline(ip,sex,',');
                getline(ip,cp,',');
                getline(ip,trtbps,',');
                getline(ip,chol,',');
                getline(ip,fbs,',');
                getline(ip,restecg,',');
                getline(ip,thalachh,',');
                getline(ip,exng, ',');
                getline(ip,oldpeak,',');
                getline(ip,slp,',');
                getline(ip,caa,',');
                getline(ip,thall,',');
                getline(ip,output,'\n');

                if (cholinput == chol)
                {
                    std::cout<<"age" <<" "<<"sex"<< " " <<"cp"<<" "<<"trtbps"<<" " <<"chol"<<" "<<"fbs"<<" "<<"restecg"<< " " << "oldpeak"<< " " <<"exng"<< " "<< "thalachh"<< " "<<"slp"<< " "<< "thall"<< " "<< "caa"<< " "<<"output"<<'\n';
                    std::cout<<age <<"  "<<sex<< "   " <<cp<<"   "<<trtbps<<"   " <<chol<<"   "<<fbs<<"    "<<restecg<< "      " << oldpeak<< "      "<<exng<<"     "<< thalachh<< "     "<<slp<< "    "<<thall<< "    "<< caa<<"   "<<output<< '\n';
                }
            }
            ip.close();

        }

        if (choice == "6")
        {
            cout<<"Enter Fbs\n";
            cin>> fbsinput;

            while(ip.good())
            {
                getline(ip,age,',');
                getline(ip,sex,',');
                getline(ip,cp,',');
                getline(ip,trtbps,',');
                getline(ip,chol,',');
                getline(ip,fbs,',');
                getline(ip,restecg,',');
                getline(ip,thalachh,',');
                getline(ip,exng, ',');
                getline(ip,oldpeak,',');
                getline(ip,slp,',');
                getline(ip,caa,',');
                getline(ip,thall,',');
                getline(ip,output,'\n');

                if (fbsinput == fbs)
                {
                    std::cout<<"age" <<" "<<"sex"<< " " <<"cp"<<" "<<"trtbps"<<" " <<"chol"<<" "<<"fbs"<<" "<<"restecg"<< " " << "oldpeak"<< " " <<"exng"<< " "<< "thalachh"<< " "<<"slp"<< " "<< "thall"<< " "<< "caa"<< " "<<"output"<<'\n';
                    std::cout<<age <<"  "<<sex<< "   " <<cp<<"   "<<trtbps<<"   " <<chol<<"   "<<fbs<<"    "<<restecg<< "      " << oldpeak<< "      "<<exng<<"     "<< thalachh<< "     "<<slp<< "    "<<thall<< "    "<< caa<<"   "<<output<< '\n';
                }
            }
            ip.close();

        }

        if (choice == "7")
        {
            cout<<"Enter Restecg\n";
            cin>> restecginput;

            while(ip.good())
            {
                getline(ip,age,',');
                getline(ip,sex,',');
                getline(ip,cp,',');
                getline(ip,trtbps,',');
                getline(ip,chol,',');
                getline(ip,fbs,',');
                getline(ip,restecg,',');
                getline(ip,thalachh,',');
                getline(ip,exng, ',');
                getline(ip,oldpeak,',');
                getline(ip,slp,',');
                getline(ip,caa,',');
                getline(ip,thall,',');
                getline(ip,output,'\n');

                if (restecginput == restecg)
                {
                    std::cout<<"age" <<" "<<"sex"<< " " <<"cp"<<" "<<"trtbps"<<" " <<"chol"<<" "<<"fbs"<<" "<<"restecg"<< " " << "oldpeak"<< " " <<"exng"<< " "<< "thalachh"<< " "<<"slp"<< " "<< "thall"<< " "<< "caa"<< " "<<"output"<<'\n';
                    std::cout<<age <<"  "<<sex<< "   " <<cp<<"   "<<trtbps<<"   " <<chol<<"   "<<fbs<<"    "<<restecg<< "      " << oldpeak<< "      "<<exng<<"     "<< thalachh<< "     "<<slp<< "    "<<thall<< "    "<< caa<<"   "<<output<< '\n';
                }
            }
            ip.close();

        }

        if (choice == "8")
        {
            cout<<"Enter Thalachh\n";
            cin>> thalachhinput;

            while(ip.good())
            {
                getline(ip,age,',');
                getline(ip,sex,',');
                getline(ip,cp,',');
                getline(ip,trtbps,',');
                getline(ip,chol,',');
                getline(ip,fbs,',');
                getline(ip,restecg,',');
                getline(ip,thalachh,',');
                getline(ip,exng, ',');
                getline(ip,oldpeak,',');
                getline(ip,slp,',');
                getline(ip,caa,',');
                getline(ip,thall,',');
                getline(ip,output,'\n');

                if (thalachhinput == thalachh)
                {
                    std::cout<<"age" <<" "<<"sex"<< " " <<"cp"<<" "<<"trtbps"<<" " <<"chol"<<" "<<"fbs"<<" "<<"restecg"<< " " << "oldpeak"<< " " <<"exng"<< " "<< "thalachh"<< " "<<"slp"<< " "<< "thall"<< " "<< "caa"<< " "<<"output"<<'\n';
                    std::cout<<age <<"  "<<sex<< "   " <<cp<<"   "<<trtbps<<"   " <<chol<<"   "<<fbs<<"    "<<restecg<< "      " << oldpeak<< "      "<<exng<<"     "<< thalachh<< "     "<<slp<< "    "<<thall<< "    "<< caa<<"   "<<output<< '\n';
                }
            }
            ip.close();

        }

        if (choice == "9")
        {
            cout<<"Enter Exng\n";
            cin>> exnginput;

            while(ip.good())
            {
                getline(ip,age,',');
                getline(ip,sex,',');
                getline(ip,cp,',');
                getline(ip,trtbps,',');
                getline(ip,chol,',');
                getline(ip,fbs,',');
                getline(ip,restecg,',');
                getline(ip,thalachh,',');
                getline(ip,exng, ',');
                getline(ip,oldpeak,',');
                getline(ip,slp,',');
                getline(ip,caa,',');
                getline(ip,thall,',');
                getline(ip,output,'\n');

                if (exnginput == exng)
                {
                    std::cout<<"age" <<" "<<"sex"<< " " <<"cp"<<" "<<"trtbps"<<" " <<"chol"<<" "<<"fbs"<<" "<<"restecg"<< " " << "oldpeak"<< " " <<"exng"<< " "<< "thalachh"<< " "<<"slp"<< " "<< "thall"<< " "<< "caa"<< " "<<"output"<<'\n';
                    std::cout<<age <<"  "<<sex<< "   " <<cp<<"   "<<trtbps<<"   " <<chol<<"   "<<fbs<<"    "<<restecg<< "      " << oldpeak<< "      "<<exng<<"     "<< thalachh<< "     "<<slp<< "    "<<thall<< "    "<< caa<<"   "<<output<< '\n';
                }
            }
            ip.close();

        }

        if (choice == "10")
        {
            cout<<"Enter Oldpeak\n";
            cin>> oldpeakinput;

            while(ip.good())
            {
                getline(ip,age,',');
                getline(ip,sex,',');
                getline(ip,cp,',');
                getline(ip,trtbps,',');
                getline(ip,chol,',');
                getline(ip,fbs,',');
                getline(ip,restecg,',');
                getline(ip,thalachh,',');
                getline(ip,exng, ',');
                getline(ip,oldpeak,',');
                getline(ip,slp,',');
                getline(ip,caa,',');
                getline(ip,thall,',');
                getline(ip,output,'\n');

                if (oldpeakinput == oldpeak)
                {
                    std::cout<<"age" <<" "<<"sex"<< " " <<"cp"<<" "<<"trtbps"<<" " <<"chol"<<" "<<"fbs"<<" "<<"restecg"<< " " << "oldpeak"<< " " <<"exng"<< " "<< "thalachh"<< " "<<"slp"<< " "<< "thall"<< " "<< "caa"<< " "<<"output"<<'\n';
                    std::cout<<age <<"  "<<sex<< "   " <<cp<<"   "<<trtbps<<"   " <<chol<<"   "<<fbs<<"    "<<restecg<< "      " << oldpeak<< "      "<<exng<<"     "<< thalachh<< "     "<<slp<< "    "<<thall<< "    "<< caa<<"   "<<output<< '\n';
                }
            }
            ip.close();

        }

        if (choice == "11")
        {
            cout<<"Enter Slp\n";
            cin>> slpinput;

            while(ip.good())
            {
                getline(ip,age,',');
                getline(ip,sex,',');
                getline(ip,cp,',');
                getline(ip,trtbps,',');
                getline(ip,chol,',');
                getline(ip,fbs,',');
                getline(ip,restecg,',');
                getline(ip,thalachh,',');
                getline(ip,exng, ',');
                getline(ip,oldpeak,',');
                getline(ip,slp,',');
                getline(ip,caa,',');
                getline(ip,thall,',');
                getline(ip,output,'\n');

                if (slpinput == slp)
                {
                    std::cout<<"age" <<" "<<"sex"<< " " <<"cp"<<" "<<"trtbps"<<" " <<"chol"<<" "<<"fbs"<<" "<<"restecg"<< " " << "oldpeak"<< " " <<"exng"<< " "<< "thalachh"<< " "<<"slp"<< " "<< "thall"<< " "<< "caa"<< " "<<"output"<<'\n';
                    std::cout<<age <<"  "<<sex<< "   " <<cp<<"   "<<trtbps<<"   " <<chol<<"   "<<fbs<<"    "<<restecg<< "      " << oldpeak<< "      "<<exng<<"     "<< thalachh<< "     "<<slp<< "    "<<thall<< "    "<< caa<<"   "<<output<< '\n';
                }
            }
            ip.close();

        }

        if (choice == "12")
        {
            cout<<"Enter Caa\n";
            cin>> caainput;

            while(ip.good())
            {
                getline(ip,age,',');
                getline(ip,sex,',');
                getline(ip,cp,',');
                getline(ip,trtbps,',');
                getline(ip,chol,',');
                getline(ip,fbs,',');
                getline(ip,restecg,',');
                getline(ip,thalachh,',');
                getline(ip,exng, ',');
                getline(ip,oldpeak,',');
                getline(ip,slp,',');
                getline(ip,caa,',');
                getline(ip,thall,',');
                getline(ip,output,'\n');

                if (caainput == caa)
                {
                    std::cout<<"age" <<" "<<"sex"<< " " <<"cp"<<" "<<"trtbps"<<" " <<"chol"<<" "<<"fbs"<<" "<<"restecg"<< " " << "oldpeak"<< " " <<"exng"<< " "<< "thalachh"<< " "<<"slp"<< " "<< "thall"<< " "<< "caa"<< " "<<"output"<<'\n';
                    std::cout<<age <<"  "<<sex<< "   " <<cp<<"   "<<trtbps<<"   " <<chol<<"   "<<fbs<<"    "<<restecg<< "      " << oldpeak<< "      "<<exng<<"     "<< thalachh<< "     "<<slp<< "    "<<thall<< "    "<< caa<<"   "<<output<< '\n';
                }
            }
            ip.close();

        }

        if (choice == "13")
        {
            cout<<"Enter Thall\n";
            cin>> thallinput;

            while(ip.good())
            {
                getline(ip,age,',');
                getline(ip,sex,',');
                getline(ip,cp,',');
                getline(ip,trtbps,',');
                getline(ip,chol,',');
                getline(ip,fbs,',');
                getline(ip,restecg,',');
                getline(ip,thalachh,',');
                getline(ip,exng, ',');
                getline(ip,oldpeak,',');
                getline(ip,slp,',');
                getline(ip,caa,',');
                getline(ip,thall,',');
                getline(ip,output,'\n');

                if (thallinput == thall)
                {
                    std::cout<<"age" <<" "<<"sex"<< " " <<"cp"<<" "<<"trtbps"<<" " <<"chol"<<" "<<"fbs"<<" "<<"restecg"<< " " << "oldpeak"<< " " <<"exng"<< " "<< "thalachh"<< " "<<"slp"<< " "<< "thall"<< " "<< "caa"<< " "<<"output"<<'\n';
                    std::cout<<age <<"  "<<sex<< "   " <<cp<<"   "<<trtbps<<"   " <<chol<<"   "<<fbs<<"    "<<restecg<< "      " << oldpeak<< "      "<<exng<<"     "<< thalachh<< "     "<<slp<< "    "<<thall<< "    "<< caa<<"   "<<output<< '\n';
                }
            }
            ip.close();

        }

        if (choice == "14")
        {
            cout<<"Enter Output\n";
            cin>> outputinput;

            while(ip.good())
            {
                getline(ip,age,',');
                getline(ip,sex,',');
                getline(ip,cp,',');
                getline(ip,trtbps,',');
                getline(ip,chol,',');
                getline(ip,fbs,',');
                getline(ip,restecg,',');
                getline(ip,thalachh,',');
                getline(ip,exng, ',');
                getline(ip,oldpeak,',');
                getline(ip,slp,',');
                getline(ip,caa,',');
                getline(ip,thall,',');
                getline(ip,output,'\n');

                if (outputinput == output)
                {
                    std::cout<<"age" <<" "<<"sex"<< " " <<"cp"<<" "<<"trtbps"<<" " <<"chol"<<" "<<"fbs"<<" "<<"restecg"<< " " << "oldpeak"<< " " <<"exng"<< " "<< "thalachh"<< " "<<"slp"<< " "<< "thall"<< " "<< "caa"<< " "<<"output"<<'\n';
                    std::cout<<age <<"  "<<sex<< "   " <<cp<<"   "<<trtbps<<"   " <<chol<<"   "<<fbs<<"    "<<restecg<< "      " << oldpeak<< "      "<<exng<<"     "<< thalachh<< "     "<<slp<< "    "<<thall<< "    "<< caa<<"   "<<output<< '\n';
                }
            }
            ip.close();

        }

        if(choice == "15")
        {
            while(getline(ip, row_data))
            {
                row.push_back(row_data);

            }

            sort(row.begin(), row.end());


            for (size_t i = 0; i < row.size(); i++)
                cout << row[i] << '\n';
        }

        if (choice == "16")
        {
            cout<<"Thanks for searching";
            ip.close();
            return 0;
        }
    }
}
